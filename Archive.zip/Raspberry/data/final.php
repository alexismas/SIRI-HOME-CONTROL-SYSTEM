<?php
	
	echo exec('./final ');

?>