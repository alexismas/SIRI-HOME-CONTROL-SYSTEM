<?php
	
	echo exec('./email ');

?>