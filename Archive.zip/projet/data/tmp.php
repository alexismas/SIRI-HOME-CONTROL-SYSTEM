<?php
	$lines = file("tmp.txt");
	foreach($lines as $n => $line){
	echo $line ;//echo $line . "<br />";
	}
?>